This is a Tic Tac Toe game written in C for the Ti-84+CE

This is my first C program ever, so you'd better like it! >:3

This game is super simple, you take turns putting pieces on a board and try to get 3 in a row. 
Enjoy!

Update (11/14) : [Clear] actually exits during the game over screen, and A cat's game gives you a Tie message instead of a weird flicker

~Pieman7373 2018